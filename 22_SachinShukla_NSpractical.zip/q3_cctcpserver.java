import java.util.*;
import java.io.*;
import java.net.Socket;
import java.net.ServerSocket;
import java.net.SocketException;

public class q3_cctcpserver
{
	public static void main(String args[]) throws IOException
	{
		Scanner sc=new Scanner(System.in);
		ServerSocket ss=new ServerSocket(1234);
		Socket sk=ss.accept();
		BufferedReader br=new BufferedReader(new InputStreamReader(sk.getInputStream()));
		String s;
		String es=br.readLine();
		System.out.println("Encrypted Text: "+es+" successfully received!");
		s=decrypt(es);
		System.out.println("Encrypted Text: "+s+" successfully Decrypted!");		
	}
	
	public static String decrypt(String s)
	{
		StringBuilder sb=new StringBuilder();
		char c;
		for(int i=0; i<s.length(); i++)
		{
			if((s.charAt(i)>='a' && s.charAt(i)<='z') || (s.charAt(i)>='A' && s.charAt(i)<='Z'))
			{
				if(s.charAt(i)>='x')
				{
					c=(char)(s.charAt(i)-23);
					sb.append(c);
					continue;					
				}
				else if(s.charAt(i)>='X' && s.charAt(i)<=90)
				{
					c=(char)(s.charAt(i)-23);
					sb.append(c);
					continue;
				}
				c=(char)(s.charAt(i)+3);
				sb.append(c);
				continue;
			}
			else if(s.charAt(i)>='0' && s.charAt(i)<='9')
			{
				if(s.charAt(i)>='7')
				{
					c=(char)(s.charAt(i)-7);
					sb.append(c);
					continue;					
				}
				c=(char)(s.charAt(i)+3);
				sb.append(c);
				continue;
			}
			sb.append(s.charAt(i));
		}
		return sb.toString();
	}
}
