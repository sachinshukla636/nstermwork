import java.util.*;
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class q3udpeven
{
	public static void main(String args[]) throws IOException
	{
		DatagramSocket ds=new DatagramSocket(1234);
		InetAddress ip=InetAddress.getLocalHost();
		while(true)
		{
			byte buf[]=new byte[65535];
			String es;
			DatagramPacket dp=new DatagramPacket(buf,buf.length);
			ds.receive(dp);
			es=new String(buf).trim();
			if(es.equalsIgnoreCase("exit"))
			{
				System.out.println("Exiting!");
				break;
			}
			System.out.println("Even number: "+es+" successfully received!");	
		}		
	}
}
