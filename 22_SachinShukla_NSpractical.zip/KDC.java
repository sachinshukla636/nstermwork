
import java.io.*;
import java.net.*;

public class KDC{
	public static void main(String[] args){
		try{
			ServerSocket serverSocket = new ServerSocket(4567);
			System.out.println("KDC server getting started......");
			System.out.println("waiting for client connection.......");
			
			while(true){
				Socket socket = serverSocket.accept();
				System.out.println("connected to client......");
				
				InputStream sInput = socket.getInputStream();
				OutputStream sOutput = socket.getOutputStream();
				
				KdcHandler kdc = new KdcHandler(sInput,sOutput);
				kdc.performTasks();
				
				socket.close();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}