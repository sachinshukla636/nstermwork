import java.util.*;
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class q3udp
{
	public static void main(String args[]) throws IOException
	{
		Scanner sc=new Scanner(System.in);
		DatagramSocket ds=new DatagramSocket();
		InetAddress ip=InetAddress.getLocalHost();
		byte buf[]=null;
		String s;
		while(true)
		{
			s="";
			System.out.println("Enter Number: ");
			s=sc.nextLine();
			buf=null;
			buf=s.getBytes();
			DatagramPacket dp=new DatagramPacket(buf,buf.length,ip,1233);
			ds.send(dp);
			if(s.equalsIgnoreCase("exit"))
			{
				System.out.println("Exiting!");
				break;
			}
			System.out.println("String: "+s+" sent Successfully!");
		}
	}
}
