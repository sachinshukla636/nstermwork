//import bsr.*;
public class DoRSA
{  
 
 public static void main(String[] argv) throws Exception
 {
     RSA d=new RSA();
   byte[] str=d.doEncryption("SachinShukla");
   System.out.println("Encrypted String : "+str);
   System.out.println("Encrypted String : "+d.doDecryption(str));
    
 }
}