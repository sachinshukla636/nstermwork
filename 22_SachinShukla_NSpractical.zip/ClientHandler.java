import java.io.*;
import java.net.*;
import javax.crypto.*;
import java.security.*;
import javax.crypto.spec.*;

public class ClientHandler{
	
	private SecretKeySpec sessionKey;
	private SecretKeySpec secretKey;
	
	public ClientHandler(){
		String key = "*&^%$#@!";
		secretKey = new SecretKeySpec(key.getBytes(),"DES");
	}
	
	private void getSessionKeyFromKdc(){
		try{
			Socket socket = new Socket("127.0.0.1",4567);
			InputStream sInput = socket.getInputStream();
			OutputStream sOutput = socket.getOutputStream();
			
			DataInputStream disFromKdc = new DataInputStream(sInput);
			
			while(disFromKdc.available()==0){}
			int len = disFromKdc.readInt();
			
			while(disFromKdc.available()==0){}
			byte[] encryptedSessionKey = new byte[len];
			disFromKdc.read(encryptedSessionKey,0,len);
			socket.close();
			
			System.out.println("encrypted session key is received......");
			
			Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE,secretKey);
			
			byte[] sessionKeyByte = cipher.doFinal(encryptedSessionKey);
			sessionKey = new SecretKeySpec(sessionKeyByte,"DES");
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	private void getFileFromServer(){
		try{
			Socket socket = new Socket("127.0.0.1",3421);
			
			InputStream is = socket.getInputStream();
			OutputStream os = socket.getOutputStream();
			
			DataInputStream disFromServer = new DataInputStream(new BufferedInputStream(is));
			String fileName = disFromServer.readUTF();
			
			Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE,sessionKey);
			
			BufferedOutputStream bos = new BufferedOutputStream	(new FileOutputStream(new File(fileName)));
			CipherOutputStream cos = new CipherOutputStream(bos,cipher);
			byte[] fileData = new byte[100];
			int no;
			
			while((no = disFromServer.read(fileData))!=-1){
				cos.write(fileData,0,no);
				cos.flush();
			}
			cos.close();
			bos.close();
			System.out.println("file received from server.......");
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public void performTasks(){
		try{
			getSessionKeyFromKdc();
			getFileFromServer();
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
