import java.util.*;
import java.io.*;
import java.net.*;

public class q2tcpfirewall
{
	public static void main(String args[]) throws IOException
	{
		ServerSocket ss=new ServerSocket(1233);
		Socket ds=ss.accept();
		BufferedReader br=new BufferedReader(new InputStreamReader(ds.getInputStream()));
		String s;
		s=br.readLine();
		System.out.println("String successfully received: "+s);
		Socket sk1=new Socket("127.0.0.1",1234);
		DataOutputStream dos=new DataOutputStream(sk1.getOutputStream());
		if(checkString(s)==null)
		{
			dos.writeBytes(s+"\n");	
			System.out.println("String successfully sent as it is valid: "+s);		
		}
		else
		{
			System.out.println("String "+s+" Not Sent!");
			System.out.println("Illegal Word is used in the String to be sended: "+checkString(s));
		}		
	}
	public static String checkString(String s)throws IOException
	{
		BufferedReader br=new BufferedReader(new FileReader("keywords.txt"));
		String temp="";
		while((temp=br.readLine())!=null)
		{
			if((s.toUpperCase()).contains(temp))
			{
				return temp;
			}
		}
		return null;
	}
}
