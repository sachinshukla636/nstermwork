import java.util.*;
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class q3udpfirewall
{
	public static void main(String args[]) throws IOException
	{
		DatagramSocket ds=new DatagramSocket(1233);
		DatagramSocket ds1=new DatagramSocket();
		InetAddress ip=InetAddress.getLocalHost();
		while(true)
		{			
			byte buf[]=new byte[65535];
			byte buf1[]=new byte[65535];
			String s;
			DatagramPacket dp=new DatagramPacket(buf,buf.length);
			ds.receive(dp);
			s=new String(buf).trim();
			buf1=s.getBytes();
			if(s.equalsIgnoreCase("exit"))
			{
				System.out.println("Exiting!");
				DatagramPacket dp1=new DatagramPacket(buf1,buf1.length,ip,1234);
				DatagramPacket dp2=new DatagramPacket(buf1,buf1.length,ip,1235);
				ds1.send(dp1);
				ds1.send(dp2);
				break;
			}
			else
			{
				System.out.println("Number successfully received by Firewall: "+s);
				int pn=checkString(s);
				DatagramPacket dp1=new DatagramPacket(buf1,buf1.length,ip,pn);
				ds1.send(dp1);
			}
		}
	}
	
	public static int checkString(String s)
	{
		int n=Integer.parseInt(s);
		if(n%2==0)
		{
			System.out.println(n+" is Even Number and forwarded to 1234");
			return 1234;
		}
		else
		{
			System.out.println(n+" is ODD Number and forwarded to 1235");
			return 1235;
		}
	}
}
