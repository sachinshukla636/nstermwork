
import javax.crypto.*;
import javax.crypto.spec.*;

public class information{
	public String Id;
	public SecretKeySpec secretKey;
	
	public information(String id,String key){
		Id = id;
		byte[] keyBytes = key.getBytes();
		secretKey = new SecretKeySpec(keyBytes,"DES");
	}
}
