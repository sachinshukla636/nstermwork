import java.util.*;
import java.io.*;
import java.net.*;

public class q2tcp
{
	public static void main(String args[]) throws IOException
	{
		Scanner sc=new Scanner(System.in);
		Socket ds=new Socket("127.0.0.1",1233);
		DataOutputStream dos=new DataOutputStream(ds.getOutputStream());
		String s;
		System.out.println("Enter String to be Sent: ");
		s=sc.nextLine();
		dos.writeBytes(s+"\n");	
		System.out.println("String: "+s+" sent to Firewall!");
	}
	
	
}
