import java.io.*;
import java.net.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.security.*;

public class KdcHandler{
	
	private information serverInfo;
	private information clientInfo;
	private OutputStream sOutput;
	private InputStream sInput;
	private byte[] sessionKey;
	private byte[] encryptedSessionKey;
	
	public KdcHandler(InputStream i,OutputStream o){
		try{
			sInput = i;
			sOutput = o;
			sessionKey = new byte[8];
			serverInfo = new information("Server#q1","!@#$%^&*");
			clientInfo = new information("Client#q1","*&^%$#@!");
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	private void generateSessionKey(){
		try{
			SecureRandom random = new SecureRandom();
			random.nextBytes(sessionKey);
			System.out.println("session key is generated......");
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	private void sendSessionKeyToClient(){
		try{
			Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE,clientInfo.secretKey);
			encryptedSessionKey = cipher.doFinal(sessionKey);
			
			DataOutputStream dosToClient = new DataOutputStream(sOutput);
			dosToClient.writeInt(encryptedSessionKey.length);
			dosToClient.write(encryptedSessionKey,0,encryptedSessionKey.length);
			System.out.println("session key is send to client.....");
			dosToClient.close();
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	private void sendSessionKeyToServer(){
		try{
			Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE,serverInfo.secretKey);
			encryptedSessionKey = cipher.doFinal(sessionKey);
			
			Socket socket = new Socket("127.0.0.1",3421);
			DataOutputStream dosToServer = new DataOutputStream(socket.getOutputStream());
			dosToServer.writeInt(encryptedSessionKey.length);
			dosToServer.write(encryptedSessionKey,0,encryptedSessionKey.length);
			System.out.println("session key is send to server.....");
			dosToServer.close();
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public void performTasks(){
		try{
			generateSessionKey();
			sendSessionKeyToClient();
			sendSessionKeyToServer();
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
